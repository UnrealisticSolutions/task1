﻿using System;
namespace API.Interfaces
{
    public class ApplicationSettings
    {
        public string JWT_SECRET { get; set; }
    }
}
