﻿using System;
namespace API.Interfaces
{
    public class UserInterface
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string mobileNumber { get; set; }
        public string password { get; set; }
    }
}
