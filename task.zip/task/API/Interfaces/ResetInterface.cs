﻿using System;
namespace API.Interfaces
{
    public class ResetInterface
    {
        public string email { get; set; }
    }
}
