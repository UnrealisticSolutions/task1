﻿using System;
namespace API.Interfaces
{
    public class LoginInterface
    {
        public string email { get; set; }
        public string password { get; set; }
    }
}
