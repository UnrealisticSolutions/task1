import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { RequestResetPassword } from '../../models/request-reset-password';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit, OnDestroy {

  resetForm: FormGroup;
  Subscriber: Subscription;
  isLoading: boolean = false;
  constructor(
    private authService: AuthService,
    private toastr: ToastrService,
    private router: Router
  ) {
    this.resetForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email])
    });
  }
  ngOnDestroy(): void {
    if (this.Subscriber) {
      this.Subscriber.unsubscribe();
    }
  }

  get email() { return this.resetForm.get('email'); }

  ngOnInit(): void {
  }

  submit() {
    if (this.resetForm.valid) {
      this.isLoading = true;
      const resetPassword = new RequestResetPassword();
      resetPassword.email = this.resetForm.get("email").value;

      this.Subscriber = this.authService.requestResetPassword(resetPassword).subscribe(
        (res: any) => {
          if (res.success) {
            this.authService.resetPasswordMail.next(resetPassword.email);
            this.isLoading = false;
            this.router.navigate(['auth/resetpassword_confirm'])
          }
          else {
            this.toastr.error('Email not found!', 'Email Not Found!');
            this.isLoading = false;
          }
        },
        error => {
          this.isLoading = false;
          this.toastr.error('Email not found!', 'Email Not Found!');
          console.log(error);
        }
      )
    }
  }

}
