import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { Login } from '../../models/login';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  subscriber: Subscription;
  loginForm: FormGroup;
  isLoading: boolean = false;

  constructor(
    private auth: AuthService,
    private router: Router,
    private toastr: ToastrService
  ) {
    this.loginForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required])
    });
  }
  ngOnDestroy(): void {
    if (this.subscriber) {
      this.subscriber.unsubscribe();
    }
  }

  ngOnInit(): void {

  }

  get email() { return this.loginForm.get('email'); }
  get password() { return this.loginForm.get('password'); }

  submit() {
    if (this.loginForm.valid) {
      this.isLoading = true;
      const login = new Login();
      login.email = this.loginForm.get('email').value;
      login.password = this.loginForm.get('password').value;

      this.subscriber = this.auth.login(login).subscribe(
        (res: any) => {
          if (res.token) {
            this.auth.token = res.token;
            this.router.navigate(['dashboard']);
          } else {
            this.toastr.error('Invalid email or password', 'Login failed!');
          }
          this.isLoading = false;
        },
        error => {
          this.isLoading = false;
          this.toastr.error('Invalid email or password', 'Login failed!');
          console.log(error);
        }
      )
    }
  }

}
