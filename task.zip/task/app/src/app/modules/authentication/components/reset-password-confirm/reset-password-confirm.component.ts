import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { ResetPasswordConfirm } from '../../models/reset-password-confirm';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-reset-password-confirm',
  templateUrl: './reset-password-confirm.component.html',
  styleUrls: ['./reset-password-confirm.component.scss']
})
export class ResetPasswordConfirmComponent implements OnInit, OnDestroy {

  resetPasswordConfirm: FormGroup;
  subscriber: Subscription;
  emaiSubscriber: Subscription;
  email: string | null;
  isLoading: boolean = false;

  constructor(private toastr: ToastrService, private router: Router, private authServie: AuthService) {
    this.resetPasswordConfirm = new FormGroup({
      code: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required]),
      confrimPassword: new FormControl('', [Validators.required])
    });
  }

  get code() { return this.resetPasswordConfirm.get('code'); }
  get password() { return this.resetPasswordConfirm.get('password'); }
  get confrimPassword() { return this.resetPasswordConfirm.get('confrimPassword'); }
  ngOnDestroy(): void {
    if (this.subscriber) {
      this.subscriber.unsubscribe();
    }

    if (this.emaiSubscriber) {
      this.emaiSubscriber.unsubscribe();
    }
  }

  ngOnInit(): void {
    this.emaiSubscriber = this.authServie.getResetPasswordMail.subscribe(
      email => {
        if (email) {
          this.email = email;
        }
        else {
          this.router.navigate(['']);
        }
      }
    )
  }

  submit() {
    if (this.resetPasswordConfirm.valid) {
      this.isLoading = true;
      const resetPassword = new ResetPasswordConfirm();
      resetPassword.email = this.email;
      resetPassword.code = this.resetPasswordConfirm.get('code').value;
      resetPassword.password = this.resetPasswordConfirm.get('password').value;

      this.subscriber = this.authServie.resetPassword(resetPassword).subscribe(
        (res: any) => {
          if (res.success) {
            this.toastr.success('Password reset successfull', 'Success!');
            this.router.navigate([''])
          } else {
            this.toastr.error('Password reset error', 'Error!');
          }
          this.isLoading = false;

        },
        error => {
          this.isLoading = false;
          this.toastr.error('Password reset error', 'Error!');
          console.log(error);
        }
      )
    }
  }

}
