import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { User } from '../../models/user';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit, OnDestroy {

  registerForm: FormGroup;
  registerSubscriber: Subscription;
  isLoading: boolean = false;

  constructor(
    private authService: AuthService,
    private toastr: ToastrService,
    private router:Router
  ) {
    this.registerForm = new FormGroup({
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      mobileNumber: new FormControl('', [Validators.required, Validators.min(9), Validators.pattern('[- +()0-9]+')]),
      password: new FormControl('', [Validators.required]),
      confirmPassword: new FormControl('', [Validators.required]),
    });
  }
  ngOnDestroy(): void {
    if (this.registerSubscriber) {
      this.registerSubscriber.unsubscribe();
    }
  }

  ngOnInit(): void {
  }

  get firstName() { return this.registerForm.get('firstName') }
  get lastName() { return this.registerForm.get('lastName') }
  get email() { return this.registerForm.get('email') }
  get mobileNumber() { return this.registerForm.get('mobileNumber') }
  get password() { return this.registerForm.get('password') }
  get confirmPassword() { return this.registerForm.get('confirmPassword') }


  checkPasswords(group: FormGroup) { // here we have the 'passwords' group
    let pass = group.get('password').value;
    let confirmPass = group.get('confirmPassword').value;
    return pass === confirmPass ? null : { notSame: true }
  }

  submit() {
    if (this.registerForm.valid) {
      this.isLoading = true;
      const user = new User();
      user.firstName = this.registerForm.get('firstName').value;
      user.lastName = this.registerForm.get('lastName').value;
      user.email = this.registerForm.get('email').value;
      user.mobileNumber = this.registerForm.get('mobileNumber').value;
      user.password = this.registerForm.get('password').value;

      this.registerSubscriber = this.authService.register(user).subscribe(
        (res: any) => {
          if (res.succeeded) {
            this.registerForm.reset();
            this.toastr.success("New user created!", "Registration successfull!");
            this.isLoading = false;
            this.router.navigate(['']);
          }
          else {
            this.isLoading = false;
            res.errors.forEach(element => {
              switch (element.code) {
                case 'DuplicateUserName':
                  this.toastr.error("Email already exists!", "Registration Failed!");
                  break;
                default:
                  this.toastr.error(element.description, "Registration Failed!");
                  break;
              }
            });
          }
        },
        error => {
          this.isLoading = false;
          console.log(error);
        }
      )
    }
  }

}
