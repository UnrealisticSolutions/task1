export class ResetPasswordConfirm {
    code:string;
    email: string;
    password: string;
}
