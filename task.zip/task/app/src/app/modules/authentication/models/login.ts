export class Login {
    email: string | null;
    password: string | null;
}
