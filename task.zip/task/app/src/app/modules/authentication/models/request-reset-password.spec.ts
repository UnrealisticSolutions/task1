import { RequestResetPassword } from './request-reset-password';

describe('RequestResetPassword', () => {
  it('should create an instance', () => {
    expect(new RequestResetPassword()).toBeTruthy();
  });
});
