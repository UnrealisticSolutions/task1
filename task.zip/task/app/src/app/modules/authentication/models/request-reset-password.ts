export class RequestResetPassword {
    email:string;
}
