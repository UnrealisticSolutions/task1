export class User {
    id:number | null;
    firstName:string;
    lastName:string;
    email:string;
    mobileNumber:string;
    password:string;
}
