import { ResetPasswordConfirm } from './reset-password-confirm';

describe('ResetPasswordConfirm', () => {
  it('should create an instance', () => {
    expect(new ResetPasswordConfirm()).toBeTruthy();
  });
});
