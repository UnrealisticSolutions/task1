import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Login } from '../models/login';
import { RequestResetPassword } from '../models/request-reset-password';
import { ResetPasswordConfirm } from '../models/reset-password-confirm';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  API_KEY = "au_tk"
  resetPasswordMail = new BehaviorSubject(null);
  getResetPasswordMail = this.resetPasswordMail.asObservable();

  
  constructor(private http: HttpClient) { }

  register(user: User) {
    return this.http.post(`${environment.baseUrl}User/Register`, user);
  }

  login(login:Login){
    return this.http.post(`${environment.baseUrl}User/Login`, login);
  }

  requestResetPassword(resetPassword:RequestResetPassword){
    return this.http.post(`${environment.baseUrl}User/Reset`, resetPassword);
  }

  resetPassword(resetPassword:ResetPasswordConfirm){
    return this.http.post(`${environment.baseUrl}User/Reset/Post`, resetPassword);
  }

  set token(token:string){
    localStorage.setItem(this.API_KEY,token);
  }

  get token(){
    return localStorage.getItem(this.API_KEY) != 'null' ? localStorage.getItem(this.API_KEY) : null;
  }


}
