import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PasswordEqualValidator } from './validators/password-equal-validator';



@NgModule({
  declarations: [PasswordEqualValidator],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports:[
    FormsModule,
    ReactiveFormsModule,
    PasswordEqualValidator,
  ]
})
export class SharedModule { }
