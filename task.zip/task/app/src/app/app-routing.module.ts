import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './modules/authentication/guards/auth.guard';
import { DashboardGuard } from './modules/authentication/guards/dashboard.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'auth',
    pathMatch: 'full'
  },
  {
    path: 'auth',
    loadChildren: () => import('./modules/authentication/authentication.module').then(m => m.AuthenticationModule),
    canActivate:[AuthGuard]
  },
  {
    path:'dashboard',
    loadChildren:()=>import('./modules/dashboard/dashboard.module').then(m=>m.DashboardModule),
    canActivate:[DashboardGuard]
  },
  {
    path:'**',
    redirectTo:'auth'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
